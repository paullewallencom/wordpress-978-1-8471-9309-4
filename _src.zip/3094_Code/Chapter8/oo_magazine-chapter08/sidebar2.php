<div id="sidebar2">
<ul id="widgetItems">
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>
<p><b>This sidebar is Widgetized!</b><br/>
Add items via <em>Admin>Design>Widgets</im></p>
<?php endif; ?>
</ul><!--//end widgetItems-->

<div class="fakeSidebar">

<?php 
/*enter your google AdWords or AdBright or other
Associate link info here and remove the background
url from #sidbar2 in the style.css sheet*/
?>


</div><!--//end fakeSidebar-->

</div><!--//sidebar2-->