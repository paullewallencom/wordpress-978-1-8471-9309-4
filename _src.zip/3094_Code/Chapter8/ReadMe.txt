This packet contains the entire theme with the following changes as described in detail in chapter 08: 

- sidebar2.php and functions.php has the "widgetized" code in place

- home.php and header.php contain the include calls to the thickbox and jQuery files

- the thickbox-code directory and js directory MUST be uploaded with this theme for the feature to work.


The following plugins as they were installed are also included. You may download the newest versions of these plugins from their source:

Ajax Comments: by Mike Smullin - http://wordpress.smullindesign.com/plugins/ajax-comments

Google Reader: by James Wilson - http://wordpress.org/extend/plugins/google-reader-widget/

pageMash: by Joel Starnes - http://wordpress.org/extend/plugins/pagemash/
  