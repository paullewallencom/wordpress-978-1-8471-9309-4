This packet contains the entire theme as described in chapter 03: 

upload it to your "wp-content/theme" directory and activate it via the Administration>Design>Theme (or Administration>Presentation>Theme in version 2.3 or less). 
  