             ______________________________ 
              WordPress Theme Design
             ______________________________



Chapter 1 - No codes
Chapter 2 - Code Present
Chapter 3 - Code Present
Chapter 4 - No codes
Chapter 5 - No codes
Chapter 6 - No codes
Chapter 7 - Code Present
Chapter 8 - Code Present
Chapter 9 - No codes
Chapter 10 - No codes


This folder contains text files that contain the codes for the respective chapters
