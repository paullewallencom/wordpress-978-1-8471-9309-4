This packet contains only the parts of the theme discussed in chapter 07: 

upload the "flash" and "js" directory to your "wp-content/theme/oo_magazine" directory 

the flash directory contains the sample fla and swf file for the theme's internal header.

the js directory contains the suckerfish-ie-fix.js code so that the suckerfish menu works in IE6 and the objectswap.js code inserts a satay

the header.php and home.php files reference the javascript includes for the suckerfish-ie-fix.js and the objectswap.js file

the style.css sheet contains the code for the suckerfish dropdown menus.

You can install a plugin for suckerfish dropdown menus by Ryan Hellyer:
http://wordpress.org/extend/plugins/ryans-suckerfish-wordpress-dropdown-menu/
  